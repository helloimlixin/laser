from runtime.rq_imagenet_entry import launch
if __name__ == '__main__':
    launch('laser_joint')
